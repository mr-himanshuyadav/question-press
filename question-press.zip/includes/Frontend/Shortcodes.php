<?php

namespace QuestionPress\Frontend;

use QuestionPress\Utils\Template_Loader;
use QuestionPress\Utils\User_Access;
use QuestionPress\Modules\Practice\Practice_Manager;
use QuestionPress\Modules\Auth\OTP_Manager;


/**
 * Class Shortcodes
 *
 * This class handles the rendering of all frontend shortcodes.
 */
final class Shortcodes
{

	// A static property to temporarily hold session data for the script.
	private static $session_data_for_script = null;

	public static function render_practice_form()
	{
		if (! is_user_logged_in()) {
			$options = get_option('qp_settings');
			$signup_page_id = $options['signup_page'] ?? 0;
			$signup_page_url = $signup_page_id ? get_permalink($signup_page_id) : '';

			$args = [
				'signup_page_url' => $signup_page_url,
				'redirect_url' => get_permalink(), // Redirect back to this practice page
			];
			return Template_Loader::get_html('auth/login-prompt-page', 'frontend', $args);
		}

		// --- Check User Entitlements ---
		global $wpdb;
		$user_id = get_current_user_id();

		// Admins always have access
		if (! user_can($user_id, 'manage_options')) {
			$entitlements_table = $wpdb->prefix . 'qp_user_entitlements';
			$current_time = current_time('mysql');

			// Check if the user has at least one valid, active entitlement
			$has_access = $wpdb->get_var($wpdb->prepare(
				"SELECT COUNT(entitlement_id)
				 FROM {$entitlements_table}
				 WHERE user_id = %d
				 AND status = 'active'
				 AND (expiry_date IS NULL OR expiry_date > %s)
				 AND (remaining_attempts IS NULL OR remaining_attempts > 0)",
				$user_id,
				$current_time
			));

			if (! $has_access) {
				// User has no valid entitlements. Show an error message.
				$shop_page_url = function_exists('wc_get_page_id') ? get_permalink(wc_get_page_id('shop')) : home_url('/');

				return '<div id="qp-practice-app-wrapper">' .
					'<div class="qp-container" style="text-align:center; padding: 40px 20px;">' .
					'<h3 style="margin-top:0; font-size: 22px;">' . esc_html__('Access Denied', 'question-press') . '</h3>' .
					'<p style="font-size: 16px; color: #555; margin-bottom: 25px;">' . esc_html__('You do not have an active plan or you have run out of attempts.', 'question-press') . '</p>' .
					'<a href="' . esc_url($shop_page_url) . '" class="qp-button qp-button-primary" style="text-decoration: none;">' . esc_html__('Purchase Access', 'question-press') . '</a>' .
					'</div>' .
					'</div>';
			}
		}

		// --- Keep pre-fill logic ---
		if (isset($_GET['start_section_practice']) && $_GET['start_section_practice'] === 'true') {
			// ... (keep existing pre-fill script logic) ...
			// Directly render the settings form using its *new* template loader call
			return '<div id="qp-practice-app-wrapper">' . self::render_settings_form() . '</div>';
		}

		// --- Prepare data for the wrapper template ---
		$options              = get_option('qp_settings');
		$dashboard_page_id  = isset($options['dashboard_page']) ? absint($options['dashboard_page']) : 0;
		$dashboard_page_url = $dashboard_page_id ? get_permalink($dashboard_page_id) : '';

		// --- Load template parts ---
		// Step 1 data is just the dashboard URL
		$step_1_html = Template_Loader::get_html('practice/practice-form-step-1-mode', 'frontend', ['dashboard_page_url' => $dashboard_page_url]);

		// Call the other render methods which will now also use Template_Loader::get_html
		$step_2_html = self::render_settings_form();
		$step_3_html = self::render_revision_mode_form();
		$step_4_html = self::render_mock_test_form();
		$step_5_html = self::render_section_wise_practice_form();

		// --- Load the main wrapper template ---
		return Template_Loader::get_html(
			'practice/practice-form-wrapper',
			'frontend',
			[
				'dashboard_page_url' => $dashboard_page_url, // Pass again if needed directly in wrapper
				'step_1_html'        => $step_1_html,
				'step_2_html'        => $step_2_html,
				'step_3_html'        => $step_3_html,
				'step_4_html'        => $step_4_html,
				'step_5_html'        => $step_5_html,
			]
		);
	}

	// --- TEMPORARY: Keep render_settings_form etc., but remove their HTML output ---
	public static function render_settings_form()
	{
		global $wpdb;
		$term_table     = $wpdb->prefix . 'qp_terms';
		$tax_table      = $wpdb->prefix . 'qp_taxonomies';
		$subject_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'subject'");

		$subjects = [];
		if ($subject_tax_id) {
			$subjects = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT term_id AS subject_id, name AS subject_name FROM {$term_table} WHERE taxonomy_id = %d AND name != 'Uncategorized' AND parent = 0 ORDER BY name ASC",
					$subject_tax_id
				)
			);
		}

		// --- Filter subjects based on user scope ---
		$user_id                   = get_current_user_id();
		$allowed_subjects_or_all = User_Access::get_allowed_subject_ids($user_id); // Get 'all' or array of IDs
		$allowed_subjects_array  = []; // Used for filtering below
		$multiSelectDisabled     = false;

		if ($allowed_subjects_or_all !== 'all' && is_array($allowed_subjects_or_all)) {
			$allowed_subjects_array = $allowed_subjects_or_all;
			$subjects               = array_filter(
				$subjects,
				function ($subject) use ($allowed_subjects_array) {
					return isset($subject->subject_id) && in_array($subject->subject_id, $allowed_subjects_array);
				}
			);
			// Check if the filtered list is empty AND user has restrictions
			if (empty($subjects)) {
				$multiSelectDisabled = true;
			}
		}

		// Prepare arguments for the template
		$options = get_option('qp_settings');
		$args = [
			'normal_practice_limit' => $options['normal_practice_limit'] ?? 100,
			'subjects'            => $subjects,
			'allowed_subjects'    => $allowed_subjects_or_all === 'all' ? 'all' : wp_json_encode($allowed_subjects_array), // Pass 'all' or JSON array
			'multiSelectDisabled' => $multiSelectDisabled,
		];

		// Load and return the template HTML
		return Template_Loader::get_html('practice/practice-form-step-2-normal', 'frontend', $args);
	}

	public static function render_revision_mode_form()
	{
		global $wpdb;
		$term_table     = $wpdb->prefix . 'qp_terms';
		$tax_table      = $wpdb->prefix . 'qp_taxonomies';
		$subject_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'subject'");

		$subjects = [];
		if ($subject_tax_id) {
			$subjects = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT term_id AS subject_id, name AS subject_name FROM {$term_table} WHERE taxonomy_id = %d AND name != 'Uncategorized' AND parent = 0 ORDER BY name ASC",
					$subject_tax_id
				)
			);
		}

		// --- Filter subjects based on user scope ---
		$user_id                   = get_current_user_id();
		$allowed_subjects_or_all = User_Access::get_allowed_subject_ids($user_id);
		$allowed_subjects_array  = [];
		$multiSelectDisabled     = false;

		if ($allowed_subjects_or_all !== 'all' && is_array($allowed_subjects_or_all)) {
			$allowed_subjects_array = $allowed_subjects_or_all;
			$subjects               = array_filter(
				$subjects,
				function ($subject) use ($allowed_subjects_array) {
					return isset($subject->subject_id) && in_array($subject->subject_id, $allowed_subjects_array);
				}
			);
			if (empty($subjects)) {
				$multiSelectDisabled = true;
			}
		}

		// Prepare arguments for the template
		$options = get_option('qp_settings'); // <-- ADD THIS
		$args = [
			'normal_practice_limit' => $options['normal_practice_limit'] ?? 100, // <-- ADD THIS
			'subjects'            => $subjects,
			'allowed_subjects'    => $allowed_subjects_or_all === 'all' ? 'all' : wp_json_encode($allowed_subjects_array),
			'multiSelectDisabled' => $multiSelectDisabled,
		];

		// Load and return the template HTML
		return Template_Loader::get_html('practice/practice-form-step-3-revision', 'frontend', $args);
	}

	public static function render_mock_test_form()
	{
		global $wpdb;
		$term_table     = $wpdb->prefix . 'qp_terms';
		$tax_table      = $wpdb->prefix . 'qp_taxonomies';
		$subject_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'subject'");

		$subjects = [];
		if ($subject_tax_id) {
			$subjects = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT term_id AS subject_id, name AS subject_name FROM {$term_table} WHERE taxonomy_id = %d AND name != 'Uncategorized' AND parent = 0 ORDER BY name ASC",
					$subject_tax_id
				)
			);
		}

		// --- Filter subjects based on user scope ---
		$user_id                   = get_current_user_id();
		$allowed_subjects_or_all = User_Access::get_allowed_subject_ids($user_id);
		$allowed_subjects_array  = [];
		$multiSelectDisabled     = false;

		if ($allowed_subjects_or_all !== 'all' && is_array($allowed_subjects_or_all)) {
			$allowed_subjects_array = $allowed_subjects_or_all;
			$subjects               = array_filter(
				$subjects,
				function ($subject) use ($allowed_subjects_array) {
					return isset($subject->subject_id) && in_array($subject->subject_id, $allowed_subjects_array);
				}
			);
			if (empty($subjects)) {
				$multiSelectDisabled = true;
			}
		}

		// Prepare arguments for the template
		$args = [
			'subjects'            => $subjects,
			'allowed_subjects'    => $allowed_subjects_or_all === 'all' ? 'all' : wp_json_encode($allowed_subjects_array),
			'multiSelectDisabled' => $multiSelectDisabled,
		];

		// Load and return the template HTML
		return Template_Loader::get_html('practice/practice-form-step-4-mock', 'frontend', $args);
	}

	public static function render_section_wise_practice_form()
	{
		global $wpdb;
		$term_table     = $wpdb->prefix . 'qp_terms';
		$tax_table      = $wpdb->prefix . 'qp_taxonomies';
		$subject_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'subject'");

		$subjects = [];
		if ($subject_tax_id) {
			$subjects = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT term_id AS subject_id, name AS subject_name FROM {$term_table} WHERE taxonomy_id = %d AND name != 'Uncategorized' AND parent = 0 ORDER BY name ASC",
					$subject_tax_id
				)
			);
		}

		// --- Filter subjects based on user scope ---
		$user_id                   = get_current_user_id();
		$allowed_subjects_or_all = User_Access::get_allowed_subject_ids($user_id);
		$allowed_subjects_array  = [];
		$sectionWiseDisabled     = false; // Changed variable name

		if ($allowed_subjects_or_all !== 'all' && is_array($allowed_subjects_or_all)) {
			$allowed_subjects_array = $allowed_subjects_or_all;
			$subjects               = array_filter(
				$subjects,
				function ($subject) use ($allowed_subjects_array) {
					return isset($subject->subject_id) && in_array($subject->subject_id, $allowed_subjects_array);
				}
			);
			if (empty($subjects)) {
				$sectionWiseDisabled = true; // Use the new variable name
			}
		}

		// Prepare arguments for the template
		$args = [
			'subjects'            => $subjects,
			'allowed_subjects'    => $allowed_subjects_or_all === 'all' ? 'all' : wp_json_encode($allowed_subjects_array),
			'sectionWiseDisabled' => $sectionWiseDisabled, // Use the new variable name
		];

		// Load and return the template HTML
		return Template_Loader::get_html('practice/practice-form-step-5-section', 'frontend', $args);
	}


	public static function render_session_page()
	{
		if (! isset($_GET['session_id']) || ! is_numeric($_GET['session_id'])) {
			return '<div class="qp-container"><p>Error: No valid practice session was found. Please start a new session.</p></div>';
		}

		$session_id = absint($_GET['session_id']);
		$user_id    = get_current_user_id();

        // --- 1. Call the new centralized function ---
        $session_data = Practice_Manager::get_active_session_data($session_id, $user_id);

        // --- 2. Handle errors & edge cases ---
        if (is_wp_error($session_data)) {
            $error_code = $session_data->get_error_code();

            if ($error_code === 'session_completed') {
                // Session is completed, show the summary UI
                global $wpdb;
                $sessions_table = $wpdb->prefix . 'qp_user_sessions';
                $session_data_from_db = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$sessions_table} WHERE session_id = %d", $session_id));
                
                $summary_data = [
                    'final_score'     => $session_data_from_db->marks_obtained,
                    'total_attempted' => $session_data_from_db->total_attempted,
                    'correct_count'   => $session_data_from_db->correct_count,
                    'incorrect_count' => $session_data_from_db->incorrect_count,
                    'skipped_count'   => $session_data_from_db->skipped_count,
                ];
                $session_settings = json_decode($session_data_from_db->settings_snapshot, true);
                return '<div id="qp-practice-app-wrapper">' . self::render_summary_ui($summary_data, $session_id, $session_settings) . '</div>';
            
            } else {
                // All other errors (not found, permission denied, etc.)
                $options = get_option('qp_settings');
                $dashboard_page_url = isset($options['dashboard_page']) ? get_permalink($options['dashboard_page']) : home_url('/');
                return '<div class="qp-container" style="text-align: center; padding: 40px 20px;">
                    <h3 style="margin-top:0; font-size: 22px;">Session Not Found</h3>
                    <p style="font-size: 16px; color: #555; margin-bottom: 25px;">' . esc_html($session_data->get_error_message()) . '</p>
                    <a href="' . esc_url($dashboard_page_url) . '" class="qp-button qp-button-primary" style="text-decoration: none;">View Dashboard</a>
                </div>';
            }
        }

        // --- 3. Pass data to script and render UI (as before) ---
		self::$session_data_for_script = $session_data;

		$preloader_html = '<div id="qp-preloader"><div class="qp-spinner"></div></div>';
		return '<div id="qp-practice-app-wrapper">' . self::render_practice_ui() . '</div>';
	}


	public static function render_summary_ui($summaryData, $session_id = 0, $settings = [])
	{
		$options              = get_option('qp_settings');
		$dashboard_page_id  = isset($options['dashboard_page']) ? absint($options['dashboard_page']) : 0;
		$dashboard_page_url = $dashboard_page_id ? get_permalink($dashboard_page_id) : home_url('/');
		$review_page_url    = isset($options['review_page']) ? get_permalink($options['review_page']) : home_url('/');
		$session_review_url = $review_page_url ? add_query_arg('session_id', $session_id, $review_page_url) : '#';

		// --- NEW: Context-Aware Back Button Logic ---
		$is_course_test = isset($settings['course_id']) && $settings['course_id'] > 0;
		$back_button_text = esc_html__('View Dashboard', 'question-press');
		$back_button_url = $dashboard_page_url; // Default URL

		if ($is_course_test) {
			$course_id = absint($settings['course_id']);
			$course_slug = get_post_field('post_name', $course_id);
			
			if ($course_slug) {
				// Check if the dashboard is the front page to add the 'tab/' prefix
				$is_front_page = ($dashboard_page_id > 0 && get_option('show_on_front') == 'page' && get_option('page_on_front') == $dashboard_page_id);
				$tab_prefix = $is_front_page ? 'tab/' : '';
				
				// Get the base dashboard URL with a trailing slash
				$base_dashboard_url = $dashboard_page_id ? trailingslashit( get_permalink( $dashboard_page_id ) ) : trailingslashit( home_url( '/' ) );

				// Construct the new URL and text
				$back_button_text = esc_html__('Back to Course', 'question-press');
				$back_button_url = $base_dashboard_url . $tab_prefix . 'courses/' . $course_slug . '/';
			}
		}
		// --- END NEW LOGIC ---

		$accuracy = 0;
		if (isset($summaryData['total_attempted']) && $summaryData['total_attempted'] > 0) {
			$accuracy = ($summaryData['correct_count'] / $summaryData['total_attempted']) * 100;
		}

		// Determine if the session was scored
		$is_scored_session = isset($settings['marks_correct']);

		ob_start();
?>
		<div class="qp-summary-wrapper">
			<h2>Session Summary</h2>

			<?php if ($is_scored_session) : ?>
				<div class="qp-summary-score">
					<div class="label">Final Score</div><?php echo number_format($summaryData['final_score'], 2); ?>
				</div>
			<?php else : ?>
				<div class="qp-summary-score">
					<div class="label">Accuracy</div><?php echo round($accuracy, 2); ?>%
				</div>
			<?php endif; ?>

			<div class="qp-summary-stats">
				<div class="stat">
					<div class="value"><?php echo (int) $summaryData['correct_count']; ?></div>
					<div class="label">Correct</div>
				</div>
				<div class="stat">
					<div class="value"><?php echo (int) $summaryData['incorrect_count']; ?></div>
					<div class="label">Incorrect</div>
				</div>
				<div class="stat">
					<div class="value"><?php echo (int) $summaryData['skipped_count']; ?></div>
					<div class="label">Skipped</div>
				</div>
				<div class="stat accuracy">
					<div class="value"><?php echo round($accuracy, 2); ?>%</div>
					<div class="label">Accuracy</div>
				</div>
			</div>
			<div class="qp-summary-actions">
				<?php // --- MODIFIED LINE --- ?>
				<a href="<?php echo esc_url($back_button_url); ?>" class="qp-button qp-button-secondary"><?php echo $back_button_text; ?></a>
				<?php if ($session_id && $review_page_url !== '#') : ?>
					<a href="<?php echo esc_url($session_review_url); ?>" class="qp-button qp-button-primary">Review Session</a>
				<?php endif; ?>
			</div>
		</div>
	<?php
		return ob_get_clean();
	}

	// Helper function to get the session data
	public static function get_session_data_for_script()
	{
		return self::$session_data_for_script;
	}

	public static function render_practice_ui()
	{
		// Get the settings for the current session to determine the mode
		// Ensure session data is available (it should be set by render_session_page)
		$session_data = self::$session_data_for_script;
		if (! $session_data || ! isset($session_data['settings'])) {
			// Handle error: Session data not found
			return '<div class="qp-container"><p>Error: Practice session data is missing or corrupt. Cannot render UI.</p></div>';
		}
		$session_settings = $session_data['settings'];

		// Determine mode flags

		// TODO: Correctly Map to session_type and session_name
		$is_mock_test           = isset($session_settings['practice_mode']) && $session_settings['practice_mode'] === 'mock_test';
		$is_section_wise        = isset($session_settings['practice_mode']) && $session_settings['practice_mode'] === 'Section Wise Practice';
		$is_palette_mandatory = $is_mock_test || $is_section_wise;

		// Determine mode class and name
		$mode_class = 'mode-normal';
		$mode_name  = 'Practice Session';
		if ($is_mock_test) {
			// --- NEW: Check if it's a Course Test ---
			if (isset($session_settings['course_id']) && $session_settings['course_id'] > 0 && isset($session_settings['item_id']) && $session_settings['item_id'] > 0) {
				$item_title = get_the_title(absint($session_settings['item_id']));
				$mode_name = $item_title ? esc_html($item_title) : 'Course Test'; // Fallback text
				$mode_class = 'mode-course-test'; // New class for different color
			} else {
				// --- Original Mock Test Logic ---
				$mode_class = 'mode-mock-test';
				$mode_name  = 'Mock Test';
			}
		} elseif (isset($session_settings['practice_mode'])) {
			switch ($session_settings['practice_mode']) {
				case 'revision':
					$mode_class = 'mode-revision';
					$mode_name  = 'Revision Mode';
					break;
				case 'Incorrect Que. Practice':
					$mode_class = 'mode-incorrect';
					$mode_name  = 'Incorrect Practice';
					break;
				case 'Section Wise Practice':
					$mode_class = 'mode-section-wise';
					$mode_name  = 'Section Wise Practice';
					break;
			}
		} elseif (isset($session_settings['subject_id']) && $session_settings['subject_id'] === 'review') {
			$mode_class = 'mode-review';
			$mode_name  = 'Review Mode';
		}

		// Check user permission for source meta
		$options              = get_option('qp_settings');
		$user                 = wp_get_current_user();
		$allowed_roles        = isset($options['show_source_meta_roles']) ? $options['show_source_meta_roles'] : [];
		$user_can_view_source = ! empty(array_intersect((array) ($user->roles ?? []), (array) $allowed_roles));

		// Prepare arguments for the template
		$args = [
			'mode_class'           => $mode_class,
			'mode_name'            => $mode_name,
			'is_mock_test'         => $is_mock_test,
			'is_section_wise'      => $is_section_wise,
			'user_can_view_source' => $user_can_view_source,
			'session_settings'     => $session_settings, // Pass the whole settings array
			'is_palette_mandatory' => $is_palette_mandatory,
		];

		// Load and return the template HTML
		return Template_Loader::get_html('practice/practice-ui', 'frontend', $args);
	}

	public static function render_review_page() {
        if ( ! is_user_logged_in() ) {
            return '<p>You must be logged in to review a session. <a href="' . wp_login_url( get_permalink() ) . '">Click here to log in.</a></p>';
        }

        if ( ! isset( $_GET['session_id'] ) || ! is_numeric( $_GET['session_id'] ) ) {
            return '<div class="qp-container"><p>Error: No valid session ID was provided.</p></div>';
        }

        $session_id = absint( $_GET['session_id'] );
        $user_id    = get_current_user_id();

        // 1. Get all data from our new reusable function
        $data = \QuestionPress\Utils\Dashboard_Manager::get_session_review_data( $session_id, $user_id );

        if ( is_null( $data ) ) {
            return '<div class="qp-container"><p>Error: Session not found or you do not have permission to view it.</p></div>';
        }

        // 2. Prepare args for the web template
        $options = get_option( 'qp_settings' );
        $dashboard_page_url = isset( $options['dashboard_page'] ) ? get_permalink( $options['dashboard_page'] ) : home_url( '/' );

        // --- Context-Aware Back Button Logic (from your original function) ---
        $settings = $data['settings'];
        $is_course_test = isset( $settings['course_id'] ) && $settings['course_id'] > 0;
        $back_button_text = esc_html__( 'Go Back', 'question-press' );
        $back_button_url = "javascript:window.history.back();";
        $back_button_onclick = "window.history.back(); return false;";
        $back_button_tag = "button";

        if ( $is_course_test ) {
            $course_id = absint( $settings['course_id'] );
            $course_slug = get_post_field( 'post_name', $course_id );
            
            if ( $course_slug ) {
                $dashboard_page_id = isset( $options['dashboard_page'] ) ? absint( $options['dashboard_page'] ) : 0;
                $base_dashboard_url = $dashboard_page_id ? trailingslashit( get_permalink( $dashboard_page_id ) ) : trailingslashit( home_url( '/' ) );
                $is_front_page = ( $dashboard_page_id > 0 && get_option( 'show_on_front' ) == 'page' && get_option( 'page_on_front' ) == $dashboard_page_id );
                $tab_prefix = $is_front_page ? 'tab/' : '';

                $back_button_text = esc_html__( 'Go to Course', 'question-press' );
                $back_button_url = $base_dashboard_url . $tab_prefix . 'courses/' . $course_slug . '/';
                $back_button_onclick = ""; 
                $back_button_tag = "a";
            }
        }
        // --- End Back Button Logic ---

        // 3. Pass all data to the template loader
        $args = [
            'session' => $data['session'],
            'accuracy' => $data['accuracy'],
            'avg_time_per_question' => $data['avg_time_per_question'],
            'marks_correct' => $data['marks_correct'],
            'marks_incorrect' => $data['marks_incorrect'],
            'topics_in_session' => $data['topics_in_session'],
            'mode' => $data['mode'],
            'mode_class' => $data['mode_class'],
            'is_course_item_deleted' => $data['is_course_item_deleted'],
            'is_section_wise_practice' => $data['is_section_wise_practice'],
            'reported_qids_for_user' => $data['reported_qids_for_user'],
            'attempts' => $data['questions'], // <-- KEY CHANGE: $attempts is now $data['questions']
            'settings' => $data['settings'],
            'session_id' => $session_id, // Pass this explicitly
            'options' => $options, // Pass options for admin roles
            
            // Back button vars
            'dashboard_page_url' => $dashboard_page_url,
            'back_button_text' => $back_button_text,
            'back_button_url' => $back_button_url,
            'back_button_tag' => $back_button_tag,
            'back_button_onclick' => $back_button_onclick,
        ];

        // 4. Load the template
        // We use 'session/review' for organization
        return \QuestionPress\Utils\Template_Loader::get_html( 'session/review', 'frontend', $args );
    }


	public static function render_signup_form()
	{
		// --- 1. Handle Logged-in / Registration Disabled ---
		if (is_user_logged_in()) {
			$options = get_option('qp_settings');
			$dashboard_url = $options['dashboard_page'] ? get_permalink($options['dashboard_page']) : home_url('/');
			return '<div class="qp-container"><p>' . esc_html__('You are already logged in.', 'question-press') . '</p><a href="' . esc_url($dashboard_url) . '" class="qp-button qp-button-primary">' . esc_html__('Go to Dashboard', 'question-press') . '</a></div>';
		}

		if (! get_option('users_can_register')) {
			return '<div class="qp-container"><p>' . esc_html__('User registration is not currently allowed.', 'question-press') . '</p></div>';
		}

		global $wpdb;
		$errors = [];
		$options = get_option('qp_settings');
		$enable_otp = (bool) ($options['enable_otp_verification'] ?? 0);

		// Ensure session is started
		if ( session_status() === PHP_SESSION_NONE && ! headers_sent() ) {
            session_start();
        }

		// --- 2. Handle All Form Submissions ---
		if (! empty($_POST) && isset($_POST['action'])) {
			check_admin_referer('qp_signup_nonce');

			// --- ACTION: User submitted the main signup form ---
			if ($_POST['action'] === 'qp_signup_submit') {
				$username = sanitize_user($_POST['qp_reg_username'] ?? '');
				$email = sanitize_email($_POST['qp_reg_email'] ?? '');
				$display_name = sanitize_text_field($_POST['qp_reg_display_name'] ?? '');
				$password = $_POST['qp_reg_password'] ?? '';
				$confirm_password = $_POST['qp_reg_confirm_password'] ?? '';
				$exam_id = isset($_POST['qp_reg_exam']) ? absint($_POST['qp_reg_exam']) : 0;
				$subject_ids = isset($_POST['qp_reg_subject']) && is_array($_POST['qp_reg_subject']) ? array_map('absint', $_POST['qp_reg_subject']) : [];

				// --- Validation ---
				if (empty($username) || empty($email) || empty($display_name) || empty($password) || empty($confirm_password)) {
					$errors[] = 'All required fields (*) are mandatory.';
				}
				if (! is_email($email)) {
					$errors[] = 'Please provide a valid email address.';
				}
				if (username_exists($username)) {
					$errors[] = 'That username is already taken. Please choose another.';
				}
				if (email_exists($email)) {
					$errors[] = 'That email address is already in use. Please log in.';
				}
				if ($password !== $confirm_password) {
					$errors[] = 'Your passwords do not match.';
				}
				if (strlen($password) < 8) {
					$errors[] = 'Password must be at least 8 characters long.';
				}

				if ( $exam_id === 0 && empty($subject_ids) ) {
					$errors[] = 'You must select either an Exam or at least one Subject.';
				}
				if ( $exam_id > 0 && !empty($subject_ids) ) {
					// Exam takes priority, so we will just ignore the subjects.
					$subject_ids = []; 
				}
				if ( count($subject_ids) > 5 ) {
					$errors[] = 'You can select a maximum of 5 subjects.';
				}

				if (empty($errors)) {
					// All fields are valid. Store data in session.
					$_SESSION['qp_signup_data'] = [
						'username' => $username,
						'email' => $email,
						'display_name' => $display_name,
						'password' => $password,
						'exam_id' => $exam_id,
						'subject_ids' => $subject_ids,
					];

					if ($enable_otp) {
						// --- OTP is ON: Send code and show Step 2 ---
						$otp_result = OTP_Manager::generate_and_send($email);
						if (is_wp_error($otp_result)) {
							$errors[] = $otp_result->get_error_message();
							// Stay on step 1 and show the error
						} else {
							// Success, redirect to OTP step
							wp_safe_redirect(add_query_arg('step', 'verify', get_permalink()));
							exit;
						}
					} else {
						// --- OTP is OFF: Create user directly ---
						$user_id = wp_create_user($username, $password, $email);
						if (is_wp_error($user_id)) {
							$errors[] = 'Error creating user: ' . $user_id->get_error_message();
						} else {
							// User created. Set display name and scope.
							wp_update_user(['ID' => $user_id, 'display_name' => $display_name]);
							update_user_meta($user_id, '_qp_allowed_exam_term_ids', wp_json_encode($exam_id > 0 ? [$exam_id] : []));
							update_user_meta($user_id, '_qp_allowed_subject_term_ids', wp_json_encode($subject_ids > 0 ? [$subject_ids] : []));

							// Log in and redirect
							$creds = ['user_login' => $username, 'user_password' => $password, 'remember' => true];
							wp_signon($creds, false);
							$dashboard_url = $options['dashboard_page'] ? get_permalink($options['dashboard_page']) : home_url('/');
							wp_safe_redirect($dashboard_url);
							exit;
						}
					}
				}
				// If we are here, $errors is not empty. We will fall through and re-render Step 1.

				// --- ACTION: User submitted the OTP form ---
			} elseif ($_POST['action'] === 'qp_verify_otp') {

				$step_1_data = $_SESSION['qp_signup_data'] ?? [];
				if (empty($step_1_data)) {
					$errors[] = 'Your session has expired. Please start over.';
					// Fall through to render step 1
				} else {
					// --- EXTRACT ALL DATA FROM SESSION ---
                $email = $step_1_data['email'] ?? '';
                $username = $step_1_data['username'] ?? '';
                $password = $step_1_data['password'] ?? '';
                $display_name = $step_1_data['display_name'] ?? '';
                $exam_id = $step_1_data['exam_id'] ?? 0;
                $subject_ids = $step_1_data['subject_ids'] ?? [];

					if (isset($_POST['qp_signup_submit_back'])) {
						// User clicked "Back". Clear session and go to step 1.
						unset($_SESSION['qp_signup_data']);
						wp_safe_redirect(remove_query_arg('step', get_permalink()));
						exit;
					}

					if (isset($_POST['qp_signup_submit_otp'])) {
						$otp_code = $_POST['qp_reg_otp'] ?? '';
						$verify_result = OTP_Manager::verify($email, $otp_code);

						if (is_wp_error($verify_result)) {
							$errors[] = $verify_result->get_error_message();
							// Fall through to re-render OTP form with error
						} else {
							// --- SUCCESS! Create the user ---
							$user_id = wp_create_user($step_1_data['username'], $step_1_data['password'], $step_1_data['email']);
							if (is_wp_error($user_id)) {
								$errors[] = 'Error creating user: ' . $user_id->get_error_message();
								// Fall through to re-render OTP form with error
							} else {
								// User created! Set display name and scope.
                            wp_update_user( ['ID' => $user_id, 'display_name' => $display_name] );
                            
                            // Save Scope
                            $allowed_exams = ($exam_id > 0) ? [$exam_id] : [];
                            // $allowed_subjects is already our validated $subject_ids array
                            
                            update_user_meta( $user_id, '_qp_allowed_exam_term_ids', wp_json_encode( $allowed_exams ) );
                            update_user_meta( $user_id, '_qp_allowed_subject_term_ids', wp_json_encode( $subject_ids ) );

								// Log in and redirect
								$creds = ['user_login' => $step_1_data['username'], 'user_password' => $step_1_data['password'], 'remember' => true];
								wp_signon($creds, false);

								// Clean up session
								unset($_SESSION['qp_signup_data']);

								$dashboard_url = $options['dashboard_page'] ? get_permalink($options['dashboard_page']) : home_url('/');
								wp_safe_redirect($dashboard_url);
								exit;
							}
						}
					}
				}
			} // end action check
		}

		// --- 3. Display Logic (GET request) ---
		$step_html = '';
		$current_step = isset($_GET['step']) ? $_GET['step'] : '1';
		$step_1_data = $_SESSION['qp_signup_data'] ?? [];

		if ($current_step === 'verify' && $enable_otp && !empty($step_1_data)) {
			// --- Show Step 2: OTP Verification ---
			$step_html = Template_Loader::get_html('auth/signup-otp-verify', 'frontend', [
				'email' => $step_1_data['email'] ?? '',
			]);
		} else {
			// --- Show Step 1: Main Signup Form (Default) ---
			$term_table = $wpdb->prefix . 'qp_terms';
			$tax_table = $wpdb->prefix . 'qp_taxonomies';
			$exam_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'exam'");
			$subject_tax_id = $wpdb->get_var("SELECT taxonomy_id FROM $tax_table WHERE taxonomy_name = 'subject'");
			$exams = $wpdb->get_results($wpdb->prepare("SELECT term_id, name FROM $term_table WHERE taxonomy_id = %d AND parent = 0 ORDER BY name ASC", $exam_tax_id));
			$subjects = $wpdb->get_results($wpdb->prepare("SELECT term_id, name FROM $term_table WHERE taxonomy_id = %d AND parent = 0 ORDER BY name ASC", $subject_tax_id));

			$step_html = Template_Loader::get_html('auth/signup-form', 'frontend', [
				'errors'   => $errors,
				'subjects' => $subjects,
				'exams'    => $exams
			]);
		}

		// Render the main wrapper
		return Template_Loader::get_html('auth/signup-wrapper', 'frontend', [
			'step_html' => $step_html,
			'errors'    => $errors
		]);
	}
}
