<?php

namespace QuestionPress\Rest_Api; // PSR-4 Namespace

use QuestionPress\Utils\Dashboard_Manager;
use QuestionPress\Modules\Practice\Practice_Manager;

// Exit if accessed directly.
if (! defined('ABSPATH')) {
    exit;
}

use WP_REST_Request;
use WP_Error;
use WP_REST_Response;
use QuestionPress\Database\Terms_DB; // Use our DB class
use QuestionPress\Utils\User_Access; // For course access checks
use QuestionPress\Utils\Vault_Manager; // For accessing the vault data

/**
 * Handles REST API requests for retrieving data (subjects, topics, etc.).
 */
class DataController
{

    /**
     * Callback to get all subjects.
     */
    public static function get_subjects()
    {
        global $wpdb;
        $tax_table = Terms_DB::get_taxonomies_table_name();
        $term_table = Terms_DB::get_terms_table_name();

        $subject_tax_id = Terms_DB::get_taxonomy_id_by_name('subject');

        if (!$subject_tax_id) {
            return new WP_REST_Response([], 200);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT term_id AS subject_id, name AS subject_name FROM {$term_table} WHERE taxonomy_id = %d AND parent = 0 ORDER BY name ASC",
            $subject_tax_id
        ));
        return new WP_REST_Response($results, 200);
    }

    /**
     * Callback to get all topics.
     */
    public static function get_topics()
    {
        global $wpdb;
        $tax_table = Terms_DB::get_taxonomies_table_name();
        $term_table = Terms_DB::get_terms_table_name();

        $subject_tax_id = Terms_DB::get_taxonomy_id_by_name('subject');

        if (!$subject_tax_id) {
            return new WP_REST_Response([], 200);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT term_id AS topic_id, name AS topic_name, parent AS subject_id FROM {$term_table} WHERE taxonomy_id = %d AND parent != 0 ORDER BY name ASC",
            $subject_tax_id
        ));
        return new WP_REST_Response($results, 200);
    }

    /**
     * Callback to get all exams.
     */
    public static function get_exams()
    {
        global $wpdb;
        $tax_table = Terms_DB::get_taxonomies_table_name();
        $term_table = Terms_DB::get_terms_table_name();

        $exam_tax_id = Terms_DB::get_taxonomy_id_by_name('exam');

        if (!$exam_tax_id) {
            return new WP_REST_Response([], 200); // Return empty if taxonomy doesn't exist
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT term_id as exam_id, name as exam_name FROM {$term_table} WHERE taxonomy_id = %d ORDER BY name ASC",
            $exam_tax_id
        ));

        return new WP_REST_Response($results, 200);
    }

    /**
     * Callback to get all sources and sections.
     */
    public static function get_sources()
    {
        global $wpdb;
        $tax_table = Terms_DB::get_taxonomies_table_name();
        $term_table = Terms_DB::get_terms_table_name();

        $source_tax_id = Terms_DB::get_taxonomy_id_by_name('source');

        if (!$source_tax_id) {
            return new WP_REST_Response([], 200);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT term_id AS source_id, name AS source_name, parent AS parent_id FROM {$term_table} WHERE taxonomy_id = %d ORDER BY name ASC",
            $source_tax_id
        ));
        return new WP_REST_Response($results, 200);
    }

    /**
     * Callback to get all labels.
     */
    public static function get_labels()
    {
        global $wpdb;
        $tax_table = Terms_DB::get_taxonomies_table_name();
        $term_table = Terms_DB::get_terms_table_name();
        $meta_table = Terms_DB::get_term_meta_table_name();

        $label_tax_id = Terms_DB::get_taxonomy_id_by_name('label');

        if (!$label_tax_id) {
            return new WP_REST_Response([], 200);
        }

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT t.term_id as label_id, t.name as label_name, m.meta_value as label_color
             FROM {$term_table} t
             LEFT JOIN {$meta_table} m ON t.term_id = m.term_id AND m.meta_key = 'color'
             WHERE t.taxonomy_id = %d 
             ORDER BY t.name ASC",
            $label_tax_id
        ));

        return new WP_REST_Response($results, 200);
    }

    /**
     * Retrieves the allowed scope hierarchy for the current user.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public static function get_user_scope(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        if (!$user_id) {
            return new \WP_Error('rest_unauthorized', 'User not logged in.', ['status' => 401]);
        }

        $scope_hierarchy = User_Access::get_user_scope_hierarchy($user_id);

        return new \WP_REST_Response(['success' => true, 'data' => $scope_hierarchy], 200);
    }

    /**
     * Callback to get all published qp_course posts.
     */
    public static function get_courses()
    {
        $courses = get_posts([
            'post_type' => 'qp_course',
            'post_status' => 'publish',
            'numberposts' => -1, // Get all courses
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        if (empty($courses)) {
            return new \WP_REST_Response([], 200);
        }

        // Format the data for the app
        $formatted_courses = [];
        foreach ($courses as $course_post) {
            $formatted_courses[] = [
                'id' => $course_post->ID,
                'title' => $course_post->post_title,
                // You can add more data here if you need it in the app
                // 'thumbnail_url' => get_the_post_thumbnail_url($course_post->ID, 'medium'),
            ];
        }

        return new \WP_REST_Response($formatted_courses, 200);
    }

    /**
     * Callback to get the details for a single qp_course.
     * (REVISED to match the app's detailed course/[id].tsx interfaces)
     */
    public static function get_course_details(\WP_REST_Request $request)
    {
        $course_id = (int) $request['id'];
        $user_id = get_current_user_id();

        if (! $course_id) {
            return new \WP_Error('rest_invalid_id', 'Invalid course ID.', ['status' => 400]);
        }

        // 1. Call the centralized data function. It has all the data we need.
        $data = Dashboard_Manager::get_course_structure_data($course_id, $user_id);

        // 2. Handle errors
        if (is_null($data)) {
            return new \WP_Error('rest_forbidden', 'Course not found or you do not have access.', ['status' => 403]);
        }

        // 3. Process data to match the app's interfaces (CourseDetails, CourseSection, CourseItem)
        $processed_sections = [];
        $is_previous_item_complete = true; // For progression logic

        if (! empty($data['sections'])) {
            foreach ($data['sections'] as $section) {
                $processed_items = [];

                // Get the items for this section
                $items_in_section = $data['items_by_section'][$section->section_id] ?? [];

                if (! empty($items_in_section)) {
                    foreach ($items_in_section as $item) {
                        $item_id = $item->item_id;

                        // Get progress for this item
                        $progress = $data['progress_data'][$item_id] ?? [
                            'status'        => 'not_started',
                            'session_id'    => null,
                            'attempt_count' => 0,
                        ];

                        // Progression logic
                        $is_locked = false;
                        if ($data['is_progressive'] && ! $is_previous_item_complete) {
                            $is_locked = true;
                        }

                        // Retake logic
                        $retake_limit = $data['retake_limit'];
                        $attempt_count = (int) $progress['attempt_count'];
                        $can_retake = false;
                        $retakes_left = null;

                        if ($data['allow_retakes']) {
                            if ($retake_limit === 0) {
                                $can_retake = true; // Unlimited retakes
                                $retakes_left = null; // App should interpret null as '∞'
                            } else {
                                $retakes_left = $retake_limit - $attempt_count;
                                if ($retakes_left > 0) {
                                    $can_retake = true;
                                }
                            }
                        }

                        // Build the final CourseItem object
                        $processed_items[] = [
                            'item_id'       => $item_id,
                            'title'         => $item->title,
                            'content_type'  => $item->content_type,
                            'status'        => $progress['status'],
                            'session_id'    => $progress['session_id'],
                            'attempt_count' => $attempt_count,
                            'is_locked'     => $is_locked,
                            'retake_limit'  => $retake_limit,
                            'can_retake'    => $can_retake,
                            'retakes_left'  => $retakes_left,
                        ];

                        // Update progression for next loop iteration
                        if ($data['is_progressive']) {
                            $is_previous_item_complete = ($progress['status'] === 'completed');
                        }
                    } // end foreach item
                } // end if items

                // Build the final CourseSection object
                $processed_sections[] = [
                    'section_id'  => $section->section_id,
                    'title'       => $section->title,
                    'description' => $section->description,
                    'items'       => $processed_items,
                ];
            } // end foreach section
        } // end if sections

        // 4. Determine enrollment status
        // We check if the 'back_url' (which we already calculated) goes to 'my-courses'
        $is_enrolled = (strpos($data['back_url'], 'my-courses') !== false);

        // 5. Assemble final response for the app
        $api_response_data = [
            'course_id'        => $data['course_post']->ID,
            'title'            => $data['course_post']->post_title,
            'description'      => $data['course_post']->post_content, // Map 'content' to 'description'
            'sections'         => $processed_sections, // Use 'sections' key
            'is_enrolled'      => $is_enrolled,
            'allow_retakes'    => $data['allow_retakes'],
            'progression_mode' => $data['is_progressive'] ? 'progressive' : 'free',
        ];

        // Wrap the response in our standard { success: true, data: ... } structure
        return new \WP_REST_Response(['success' => true, 'data' => $api_response_data], 200);
    }

    /**
     * Gets the data manifest for a specific session (active or completed).
     * - If 'active' or 'paused', it returns the practice manifest.
     * - If 'completed' or 'abandoned', it returns the final results summary.
     */
    public static function get_session_results(\WP_REST_Request $request)
    {
        $session_id = (int) $request['id'];
        $user_id = get_current_user_id();

        if (! $session_id) {
            return new \WP_Error('rest_invalid_id', 'Invalid session ID.', ['status' => 400]);
        }

        // 1. Check the session status
        global $wpdb;
        $sessions_table = $wpdb->prefix . 'qp_user_sessions';
        $session_status = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$sessions_table} WHERE session_id = %d AND user_id = %d",
            $session_id,
            $user_id
        ));

        if (! $session_status) {
            return new \WP_Error('rest_not_found', 'Session not found or permission denied.', ['status' => 404]);
        }

        // 2. Branch the logic
        if ($session_status === 'active' || $session_status === 'paused') {
            // --- SESSION IS ACTIVE ---
            // Call our centralized function from Practice_Manager to get the manifest
            $session_manifest = Practice_Manager::get_active_session_data($session_id, $user_id);

            if (is_wp_error($session_manifest)) {
                return $session_manifest;
            }

            // The app's interface expects a 'questions' key, but it will be empty.
            // We will add it here to prevent 'undefined' errors in the app.
            $session_manifest['questions'] = []; // App will need to fetch these

            return new \WP_REST_Response(['success' => true, 'data' => $session_manifest], 200);
        } else {
            // --- SESSION IS COMPLETED ---
            // Get final results (the original purpose of this function)
            $results = $wpdb->get_row($wpdb->prepare(
                "SELECT 
                    session_id, status, total_attempted, correct_count, 
                    incorrect_count, skipped_count, marks_obtained 
                 FROM {$sessions_table} 
                 WHERE session_id = %d",
                $session_id
            ), ARRAY_A);

            if (! $results) {
                return new \WP_Error('rest_no_data', 'Could not retrieve session results.', ['status' => 500]);
            }

            return new \WP_REST_Response(['success' => true, 'data' => $results], 200);
        }
    }

    /**
     * Callback to get the data for the main overview dashboard.
     * (REVISED TO FIX DATA MISMATCH)
     */
    public static function get_dashboard_overview(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        // 1. Call the correct data-fetching function from Dashboard.php
        $data = Dashboard_Manager::get_overview_data($user_id); //

        if (is_wp_error($data)) {
            return $data; // Pass the WP_Error object on failure
        }

        // 2. Process Active Sessions into the format the app expects
        $processed_active_sessions = [];
        foreach ($data['active_sessions'] as $session) {
            $settings = json_decode($session->settings_snapshot, true);
            $processed_active_sessions[] = [
                'session_id' => (int) $session->session_id,
                'start_time' => $session->start_time,
                'status' => $session->status,
                'mode_name' => Dashboard_Manager::get_session_mode_name($session, $settings), //
                'subjects_display' => Dashboard_Manager::get_session_subjects_display($session, $settings, $data['lineage_cache_active'], $data['group_to_topic_map_active'], $data['question_to_group_map_active']), //
                'result_display' => '-', // Active sessions don't have a result
            ];
        }

        // 3. Process Recent History into the format the app expects
        // THIS IS THE CRITICAL FIX FOR YOUR RECENT HISTORY
        $processed_recent_history = [];
        foreach ($data['recent_history'] as $session) { //
            $settings = json_decode($session->settings_snapshot, true);
            $processed_recent_history[] = [ //
                'session_id' => (int) $session->session_id,
                'start_time' => $session->start_time,
                'status' => $session->status,
                'mode_name' => Dashboard_Manager::get_session_mode_name($session, $settings), //
                'subjects_display' => Dashboard_Manager::get_session_subjects_display($session, $settings, $data['lineage_cache_recent'], $data['group_to_topic_map_recent'], $data['question_to_group_map_recent']), //
                'result_display' => $data['accuracy_stats'][$session->session_id] ?? Dashboard_Manager::get_session_result_display($session, $settings), //
            ];
        }

        // 4. Create the final clean data object for the app
        // THIS IS THE CRITICAL FIX FOR YOUR STATS
        $api_response_data = [
            'total_attempted'     => (int) $data['stats']->total_attempted,   // <-- FIX: Accessing inside 'stats' and casting to (int)
            'total_correct'       => (int) $data['stats']->total_correct,     // <-- FIX: Accessing inside 'stats' and casting to (int)
            'overall_accuracy'    => (float) $data['overall_accuracy'],
            'review_count'        => (int) $data['review_count'],
            'never_correct_count' => (int) $data['never_correct_count'],
            'active_sessions'     => $processed_active_sessions,  // <-- FIX
            'recent_history'      => $processed_recent_history, // <-- FIX: Using processed array
        ];

        // 5. Return the *wrapped* response that the app expects
        return new \WP_REST_Response(['success' => true, 'data' => $api_response_data], 200);
    }
    /**
     * Callback to get the data for the main profile dashboard.
     */
    public static function get_dashboard_profile(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        // Call the public helper function from Dashboard.php
        $profile_data = Dashboard_Manager::get_profile_data($user_id);

        if (empty($profile_data)) {
            return new \WP_Error('rest_no_data', 'Could not retrieve profile data.', ['status' => 500]);
        }

        // Return the *wrapped* response that the app expects
        return new \WP_REST_Response(['success' => true, 'data' => $profile_data], 200);
    }

    /**
     * Callback to get the review details for a specific session.
     * (This endpoint is used by the mobile app)
     */
    public static function get_session_review_details(\WP_REST_Request $request)
    {
        $session_id = (int) $request['id'];
        $user_id = get_current_user_id();

        if (! $session_id) {
            return new \WP_Error('rest_invalid_id', 'Invalid session ID.', ['status' => 400]);
        }

        // 1. Call your "correct" data-gathering function
        $data = \QuestionPress\Utils\Dashboard_Manager::get_session_review_data($session_id, $user_id);

        if (is_null($data)) {
            return new \WP_Error('rest_not_found', 'Session not found or permission denied.', ['status' => 404]);
        }

        // 2. Transform the '$data['questions']' array for the mobile app
        $app_questions = [];
        foreach ($data['questions'] as $q_obj) {

            // Transform options: The app wants {key, value}, but your DB has {id, text}.
            // We will map 'option_id' -> 'option_key' and 'option_text' -> 'option_value'.
            $transformed_options = [];
            $correct_answer_keys = []; // We'll find this while we loop
            foreach ($q_obj->options as $option_row) {
                $transformed_options[] = [
                    'option_key' => (string) $option_row->option_id, // Mapping ID to Key (as string)
                    'option_value' => $option_row->option_text, // Mapping Text to Value
                ];

                if ($option_row->is_correct) {
                    $correct_answer_keys[] = (string) $option_row->option_id; // Store all correct keys (as strings)
                }
            }

            // Your query doesn't select 'question_type'.
            // We must infer it based on the number of correct answers.
            $question_type = (count($correct_answer_keys) > 1) ? 'multiple_choice' : 'single_choice';

            // Format the correct_answer for the app
            $app_correct_answer = null;
            if ($question_type === 'multiple_choice') {
                $app_correct_answer = $correct_answer_keys; // e.g., ["123", "124"]
            } else {
                $app_correct_answer = $correct_answer_keys[0] ?? null; // e.g., "123"
            }

            // Format the user_answer for the app.
            // Your PHP function provides 'selected_option_id' from the DB.
            $app_user_answer = $q_obj->selected_option_id ? (string) $q_obj->selected_option_id : null;

            // This logic assumes 'selected_option_id' is for single-choice answers.
            // If your app supports multiple-choice answers, your 'qp_user_attempts'
            // table would need to store a JSON array, and the 'get_session_review_data'
            // function would need to be updated to pass 'user_answer' instead of 'selected_option_id'.
            // Based on your provided function, this is the correct transformation.

            $app_questions[] = [
                'question_id' => $q_obj->question_id,
                'question_text' => $q_obj->question_text,
                'direction_text' => $q_obj->direction_text,
                'question_type' => $question_type, // Our best guess
                'options' => $transformed_options,
                'explanation' => $q_obj->explanation, // This is 'explanation_text'
                'user_answer' => $app_user_answer, // This is 'selected_option_id'
                'correct_answer' => $app_correct_answer, // This is derived from $q_obj->options
                'is_correct' => $q_obj->is_correct,
                'is_marked_for_review' => $q_obj->is_marked_for_review,
                'reported_info' => $q_obj->reported_info ?? ['has_report' => false, 'has_suggestion' => false],
            ];
        }

        // 3. Use the 'app_summary' directly from your function
        // We just need to flatten it to match the app's 'SessionReviewDetails' interface
        $final_app_data = [
            'session_id' => $data['app_summary']['session_id'],
            'status' => $data['app_summary']['status'],
            'start_time' => $data['app_summary']['start_time'],
            'end_time' => $data['app_summary']['end_time'],
            'total_questions' => $data['app_summary']['total_questions'],
            'correct_count' => $data['app_summary']['correct_count'],
            'incorrect_count' => $data['app_summary']['incorrect_count'],
            'skipped_count' => $data['app_summary']['skipped_count'],
            'marks_obtained' => $data['app_summary']['marks_obtained'],
            'total_marks' => $data['app_summary']['total_marks'],
            'overall_accuracy' => $data['app_summary']['overall_accuracy'],
            'questions' => $app_questions,
        ];

        // 4. Wrap and return
        return new \WP_REST_Response(['success' => true, 'data' => $final_app_data], 200);
    }

    /**
     * Callback to get the data for the dashboard history tab.
     * (REVISED to match app's 'Session' interface)
     */
    public static function get_dashboard_history(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        $data = Dashboard_Manager::get_history_data($user_id);

        if (is_wp_error($data)) {
            return $data;
        }

        $processed_completed = [];
        foreach ($data['completed_sessions'] as $session) {
            $settings = json_decode($session->settings_snapshot, true);
            $mode_details = Dashboard_Manager::qp_get_history_mode_details($session, $settings);

            $context_display = Dashboard_Manager::get_session_context_display(
                $session,
                $settings,
                $data['lineage_cache_completed'],
                $data['group_to_topic_map_completed'],
                $data['question_to_group_map_completed'],
                $data['existing_course_item_ids']
            );

            $processed_completed[] = [
                'session_id'       => (int) $session->session_id,
                'status'           => $session->status,
                'mode_name'        => $mode_details['label'],
                'subjects_display' => wp_strip_all_tags($context_display),
                'result_display'   => Dashboard_Manager::get_session_result_display($session, $settings),
                'start_time'       => $session->start_time,
                'can_delete'       => true, // API-based deletion allowed
                'review_url'       => add_query_arg('session_id', $session->session_id, $data['review_page_url']),
                'last_activity'    => $session->last_activity,
            ];
        }

        $processed_paused = [];
        foreach ($data['paused_sessions'] as $session) {
            $settings = json_decode($session->settings_snapshot, true);
            $mode_details = Dashboard_Manager::qp_get_history_mode_details($session, $settings);

            // FIX: Use dynamic context display for paused sessions
            $context_display = Dashboard_Manager::get_session_context_display(
                $session,
                $settings,
                $data['lineage_cache_paused'],
                $data['group_to_topic_map_paused'],
                $data['question_to_group_map_paused'],
                $data['existing_course_item_ids']
            );

            $processed_paused[] = [
                'session_id'       => (int) $session->session_id,
                'status'           => $session->status,
                'mode_name'        => $mode_details['label'],
                'subjects_display' => wp_strip_all_tags($context_display),
                'result_display'   => '-',
                'start_time'       => $session->start_time,
                'can_delete'       => true, // API-based deletion allowed
                'resume_url'       => add_query_arg('session_id', $session->session_id, $data['session_page_url']),
                'last_activity'    => $session->last_activity,
            ];
        }

        return new WP_REST_Response(['success' => true, 'data' => ['completed' => $processed_completed, 'paused' => $processed_paused]], 200);
    }
    /**
     * Callback to get the data for the "My Courses" dashboard tab.
     * (REVISED to match app's 'Course' interface and expected keys)
     */
    public static function get_dashboard_my_courses(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        // 1. Call the centralized data function
        $data = Dashboard_Manager::get_my_courses_data($user_id);

        if (is_wp_error($data)) {
            return $data;
        }

        // 2. Process Enrolled Courses (from WP_Query) for the app
        $processed_enrolled = [];
        // Get the global opt-out setting
        $global_opt_out = $data['allow_global_opt_out'] ?? false;

        if ($data['enrolled_courses_query'] instanceof \WP_Query && $data['enrolled_courses_query']->have_posts()) {
            foreach ($data['enrolled_courses_query']->posts as $course_post) {
                $course_id = $course_post->ID;
                $progress_data = $data['enrolled_courses_data'][$course_id] ?? ['progress' => 0, 'is_complete' => false];

                // Check per-course opt-out meta
                $course_opt_out = get_post_meta($course_id, '_qp_course_allow_opt_out', true);

                // Logic: Allow if global is on AND per-course is not '0'
                // (empty or '1' means allow, '0' means disallow)
                $allow_opt_out = $global_opt_out && ($course_opt_out !== '0');

                $processed_enrolled[] = [
                    'id'            => $course_id,
                    'title'         => $course_post->post_title,
                    'status'        => $course_post->post_status,
                    'thumbnail'     => get_the_post_thumbnail_url($course_id, 'medium'),
                    'progress'      => $progress_data['progress'],
                    'is_complete'   => $progress_data['is_complete'],
                    'allow_opt_out' => $allow_opt_out,
                    'access_mode'   => get_post_meta($course_id, '_qp_course_access_mode', true) ?: 'free', // Get access mode, default to 'free'
                ];
            }
        }

        // 3. Process Purchased-but-Not-Enrolled Courses for the app
        $processed_purchased = [];
        if (! empty($data['purchased_not_enrolled_posts'])) {
            foreach ($data['purchased_not_enrolled_posts'] as $course_post) {
                $course_id = $course_post->ID;
                $processed_purchased[] = [
                    'id'            => $course_id,
                    'title'         => $course_post->post_title,
                    'status'        => $course_post->post_status,
                    'thumbnail'     => get_the_post_thumbnail_url($course_id, 'medium'),
                    'progress'      => 0,
                    'is_complete'   => false,
                    'allow_opt_out' => false, // Can't opt-out if not enrolled
                    'access_mode'   => get_post_meta($course_id, '_qp_course_access_mode', true) ?: 'free',
                ];
            }
        }

        // 4. Create the final clean data object
        // --- THIS IS THE FIX ---
        $api_response_data = [
            'enrolled_courses'             => $processed_enrolled,
            'purchased_not_enrolled_courses' => $processed_purchased,
        ];
        // --- END FIX ---

        return new \WP_REST_Response(['success' => true, 'data' => $api_response_data], 200);
    }
    /**
     * Callback to get the data for the "Available Courses" dashboard tab.
     * (Designed to match app's 'available-courses.tsx' screen)
     */
    public static function get_dashboard_available_courses(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        // 1. Call the centralized data function
        $data = Dashboard_Manager::get_available_courses_data($user_id);

        if (is_wp_error($data)) {
            return $data;
        }

        // 2. Process the WP_Query results into a clean array for the app
        $processed_courses = [];
        if ($data['available_courses_query'] instanceof \WP_Query && $data['available_courses_query']->have_posts()) {
            foreach ($data['available_courses_query']->posts as $course_post) {
                $course_id = $course_post->ID;
                $access_mode = get_post_meta($course_id, '_qp_course_access_mode', true) ?: 'free';
                $price_data = [
                    'regular_price' => null,
                    'sale_price'    => null,
                    'is_on_sale'    => false,
                ];

                // Get price if it's a paid course
                if ($access_mode === 'requires_purchase' && function_exists('wc_get_product')) {
                    $product_id = get_post_meta($course_id, '_qp_linked_product_id', true);
                    if ($product_id) {
                        $product = wc_get_product($product_id);
                        if ($product) {
                            $regular_price = $product->get_regular_price();
                            $sale_price    = $product->get_sale_price();

                            $price_data['regular_price'] = $regular_price ? (string)$regular_price : null;
                            $price_data['sale_price']    = $sale_price ? (string)$sale_price : null;
                            $price_data['is_on_sale']    = $product->is_on_sale();
                        }
                    }
                }

                // Build the object matching the app's interface
                $processed_courses[] = [
                    'id'          => $course_id,
                    'title'       => $course_post->post_title,
                    'status'      => $course_post->post_status, // 'publish' or 'expired'
                    'access_mode' => $access_mode, // 'free' or 'requires_purchase'
                    'price_data'       => $price_data,
                    'price'       => $price_data['sale_price'],   // TODO: Remove after updating app. Kept here for legacy support, but app should use 'price_data' object.
                ];
            }
        }

        // 3. Create the final clean data object
        // --- THIS IS THE FIX ---
        // The key 'available_courses' MUST match the app screen's expectation
        $api_response_data = [
            'available_courses' => $processed_courses,
        ];
        // --- END FIX ---

        return new \WP_REST_Response(['success' => true, 'data' => $api_response_data], 200);
    }

    /**
     * Callback to get the data for the "Review" dashboard tab.
     * (REVISED with robust sanitization to prevent JSON encoding errors)
     */
    public static function get_dashboard_review(\WP_REST_Request $request)
    {
        $user_id = get_current_user_id();

        // 1. Call the centralized data function
        $data = Dashboard_Manager::get_review_data($user_id);

        if (is_wp_error($data)) {
            return $data;
        }

        // 2. Process data for the app
        $processed_questions = [];
        if (is_array($data['review_questions'])) { // Check if it's an array first
            foreach ($data['review_questions'] as $q) {

                // --- THIS IS THE FIX ---
                // We must aggressively sanitize text to prevent JSON errors

                // 1. Ensure text is a string, handle nulls
                $text = (string) ($q->question_text ?? '');
                // 2. Remove all HTML/PHP tags
                $text = strip_tags($text);
                // 3. Convert HTML entities (like &amp;) to characters
                $text = html_entity_decode($text);
                // 4. Trim it
                $text = wp_trim_words($text, 25, '...');
                // 5. Final check to remove any lingering non-UTF8 characters
                $text = wp_check_invalid_utf8($text, true);

                // Also sanitize the subject name
                $subject = (string) ($q->subject_name ?? 'N/A');
                if (empty($subject) || $subject === 'Uncategorized') {
                    $subject = 'N/A';
                }
                // --- END FIX ---

                $processed_questions[] = [
                    'question_id'   => (int) $q->question_id,
                    'question_text' => $text,
                    'direction_text' => $q->direction_text,
                    'subject_name'  => esc_html($subject),
                ];
            }
        }

        // 3. Create the final clean data object
        $api_response_data = [
            'review_questions'      => $processed_questions,
            'never_correct_count'   => (int) $data['never_correct_count'],
            'total_incorrect_count' => (int) $data['total_incorrect_count'],
        ];

        return new \WP_REST_Response(['success' => true, 'data' => $api_response_data], 200);
    }

    /**
     * Callback to get basic user analytics directly from user meta.
     * Implementation of Streak Decay Logic (Step 1.4).
     */

    public static function get_basic_analytics(WP_REST_Request $request)
    {
        $user_id = get_current_user_id();
        $vault   = Vault_Manager::get_vault($user_id);

        $perf   = $vault->performance_snapshot ?? [];
        $streak = $vault->streak_data ?? [];

        // 1. Streak Decay Logic using Vault data
        $today          = current_time('Y-m-d');
        $yesterday      = date('Y-m-d', strtotime('-1 day', strtotime($today)));
        $last_act_date  = $streak['last_activity_date'] ?? '';
        $current_streak = (int) ($streak['current_streak'] ?? 0);

        if (!empty($last_act_date) && $last_act_date !== $today && $last_act_date !== $yesterday) {
            $current_streak = 0;
            \QuestionPress\Utils\Vault_Manager::update_streak($user_id, [
                'current_streak'     => 0,
                'last_activity_date' => $last_act_date
            ]);
        }

        $completed_today = ($last_act_date === $today);
        $streak_status   = $completed_today ? 'active' : ($current_streak > 0 ? 'at_risk' : 'inactive');

        // 2. Assemble pre-calculated stats
        $data = [
            'total_time'     => (int) ($perf['total_time'] ?? 0),
            'total_attempts' => (int) ($perf['total_attempts'] ?? 0),
            'correct_count'  => (int) ($perf['correct_count'] ?? 0),
            'accuracy'       => (float) ($perf['accuracy'] ?? 0),
            'streak'         => [
                'count'           => $current_streak,
                'completed_today' => $completed_today,
                'status'          => $streak_status,
            ],
            'advanced_enabled' => true,
        ];

        return new WP_REST_Response(['success' => true, 'data' => $data], 200);
    }

    public static function get_user_mastery(\WP_REST_Request $request)
    {
        global $wpdb;
        $user_id = get_current_user_id();

        if (! $user_id) {
            return new \WP_Error('rest_unauthorized', 'User not logged in', ['status' => 401]);
        }

        // 1. Get the explicitly allowed subjects and topics from the Vault Scope
        $scope_hierarchy = User_Access::get_user_scope_hierarchy($user_id);
        $allowed_subjects = $scope_hierarchy['subjects'] ?? [];

        if (empty($allowed_subjects)) {
            return new \WP_REST_Response(['success' => true, 'data' => []], 200);
        }

        // 2. Fetch the user's actual mastery data
        $mastery_table = $wpdb->prefix . 'qp_user_subject_mastery';
        $query = $wpdb->prepare("
        SELECT term_id, mastery_level, total_answered, correct_count
        FROM $mastery_table
        WHERE user_id = %d
    ", $user_id);

        $mastery_results = $wpdb->get_results($query, ARRAY_A);

        // 3. Index the mastery data by term_id for lightning-fast lookup
        $mastery_index = [];
        if ($mastery_results) {
            foreach ($mastery_results as $row) {
                $mastery_index[$row['term_id']] = [
                    'mastery_level'  => (float) $row['mastery_level'],
                    'total_answered' => (int) $row['total_answered'],
                    'correct_count'  => (int) $row['correct_count'],
                ];
            }
        }

        // Default stats if the user hasn't attempted a subject/topic yet
        $default_stats = [
            'mastery_level'  => 0,
            'total_answered' => 0,
            'correct_count'  => 0
        ];

        // 4. Map the mastery data onto the strictly allowed hierarchy
        $structured_data = [];

        foreach ($allowed_subjects as $subject) {
            $subject_id = $subject['id'];
            $subject_stats = $mastery_index[$subject_id] ?? $default_stats;

            $mapped_subject = [
                'term_id'        => (int) $subject_id,
                'name'           => $subject['name'],
                'parent'         => 0,
                'mastery_level'  => $subject_stats['mastery_level'],
                'total_answered' => $subject_stats['total_answered'],
                'correct_count'  => $subject_stats['correct_count'],
                'children'       => []
            ];

            // Map child topics
            if (! empty($subject['topics'])) {
                foreach ($subject['topics'] as $topic) {
                    $topic_id = $topic['id'];
                    $topic_stats = $mastery_index[$topic_id] ?? $default_stats;

                    $mapped_subject['children'][] = [
                        'term_id'        => (int) $topic_id,
                        'name'           => $topic['name'],
                        'parent'         => (int) $subject_id,
                        'mastery_level'  => $topic_stats['mastery_level'],
                        'total_answered' => $topic_stats['total_answered'],
                        'correct_count'  => $topic_stats['correct_count'],
                    ];
                }
            }

            $structured_data[] = $mapped_subject;
        }

        return new \WP_REST_Response(['success' => true, 'data' => $structured_data], 200);
    }

    /**
     * Returns sanitized content for Terms and Privacy pages.
     */
    public static function get_legal_pages(WP_REST_Request $request)
    {
        $options = get_option('qp_settings');
        $pages = [
            'terms' => isset($options['terms_page']) ? (int) $options['terms_page'] : 0,
            'privacy' => isset($options['privacy_page']) ? (int) $options['privacy_page'] : 0
        ];

        $data = [];
        foreach ($pages as $key => $id) {
            if ($id > 0) {
                $post = get_post($id);
                $data[$key] = $post ? wp_kses_post(apply_filters('the_content', $post->post_content)) : null;
            } else {
                $data[$key] = null;
            }
        }

        return new WP_REST_Response(['success' => true, 'data' => $data], 200);
    }
} // End class DataController